//-----------------------------------------------------------------------------
// File: CGameObject.cpp
//-----------------------------------------------------------------------------

#include "stdafx.h"
#include "Object.h"
#include "Shader.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
CTexture::CTexture(int nTextures, UINT nTextureType, int nSamplers, int nRootParameters)
{
	m_nTextureType = nTextureType;

	m_nTextures = nTextures;
	if (m_nTextures > 0)
	{
		m_ppd3dTextures = new ID3D12Resource * [m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_ppd3dTextures[i] = NULL;
		m_ppd3dTextureUploadBuffers = new ID3D12Resource * [m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_ppd3dTextureUploadBuffers[i] = NULL;
		m_pd3dSrvGpuDescriptorHandles = new D3D12_GPU_DESCRIPTOR_HANDLE[m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_pd3dSrvGpuDescriptorHandles[i].ptr = NULL;

		m_ppstrTextureNames = new _TCHAR * [m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_ppstrTextureNames[i] = NULL;

		m_pnResourceTypes = new UINT[m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_pnResourceTypes[i] = -1;

		m_pdxgiBufferFormats = new DXGI_FORMAT[m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_pnResourceTypes[i] = DXGI_FORMAT_UNKNOWN;
		m_pnBufferElements = new int[m_nTextures];
		for (int i = 0; i < m_nTextures; i++) m_pnBufferElements[i] = 0;
	}
	m_nRootParameters = nRootParameters;
	if (nRootParameters > 0) m_pnRootParameterIndices = new int[nRootParameters];
	for (int i = 0; i < m_nRootParameters; i++) m_pnRootParameterIndices[i] = -1;

	m_nSamplers = nSamplers;
	if (m_nSamplers > 0) m_pd3dSamplerGpuDescriptorHandles = new D3D12_GPU_DESCRIPTOR_HANDLE[m_nSamplers];
}

CTexture::~CTexture()
{
	if (m_ppd3dTextures)
	{
		for (int i = 0; i < m_nTextures; i++) if (m_ppd3dTextures[i]) m_ppd3dTextures[i]->Release();
		delete[] m_ppd3dTextures;
	}
	if (m_pnResourceTypes) delete[] m_pnResourceTypes;
	if (m_pdxgiBufferFormats) delete[] m_pdxgiBufferFormats;
	if (m_pnBufferElements) delete[] m_pnBufferElements;

	if (m_pnRootParameterIndices) delete[] m_pnRootParameterIndices;
	if (m_pd3dSrvGpuDescriptorHandles) delete[] m_pd3dSrvGpuDescriptorHandles;

	if (m_pd3dSamplerGpuDescriptorHandles) delete[] m_pd3dSamplerGpuDescriptorHandles;
}

void CTexture::SetTextureName(int nIndex, _TCHAR *pstrTextureName)
{
	size_t nLength = _tcslen(pstrTextureName) + 1;
	m_ppstrTextureNames[nIndex] = new _TCHAR[nLength];
	_tcscpy_s(m_ppstrTextureNames[nIndex], nLength, pstrTextureName);
}

void CTexture::SetRootParameterIndex(int nIndex, UINT nRootParameterIndex)
{
	m_pnRootParameterIndices[nIndex] = nRootParameterIndex;
}

void CTexture::SetGpuDescriptorHandle(int nIndex, D3D12_GPU_DESCRIPTOR_HANDLE d3dSrvGpuDescriptorHandle)
{
	m_pd3dSrvGpuDescriptorHandles[nIndex] = d3dSrvGpuDescriptorHandle;
}

void CTexture::SetSampler(int nIndex, D3D12_GPU_DESCRIPTOR_HANDLE d3dSamplerGpuDescriptorHandle)
{
	m_pd3dSamplerGpuDescriptorHandles[nIndex] = d3dSamplerGpuDescriptorHandle;
}

void CTexture::UpdateShaderVariables(ID3D12GraphicsCommandList* pd3dCommandList)
{
	if (m_nRootParameters == m_nTextures)
	{
		for (int i = 0; i < m_nRootParameters; i++)
		{
			pd3dCommandList->SetGraphicsRootDescriptorTable(m_pnRootParameterIndices[i], m_pd3dSrvGpuDescriptorHandles[i]);
		}
	}
	else
	{
		pd3dCommandList->SetGraphicsRootDescriptorTable(m_pnRootParameterIndices[0], m_pd3dSrvGpuDescriptorHandles[0]);
	}
}

void CTexture::UpdateShaderVariable(ID3D12GraphicsCommandList* pd3dCommandList, int nParameterIndex, int nTextureIndex)
{
	pd3dCommandList->SetGraphicsRootDescriptorTable(m_pnRootParameterIndices[nParameterIndex], m_pd3dSrvGpuDescriptorHandles[nTextureIndex]);
}

void CTexture::ReleaseShaderVariables()
{
}

void CTexture::ReleaseUploadBuffers()
{
	if (m_ppd3dTextureUploadBuffers)
	{
		for (int i = 0; i < m_nTextures; i++) if (m_ppd3dTextureUploadBuffers[i]) m_ppd3dTextureUploadBuffers[i]->Release();
		delete[] m_ppd3dTextureUploadBuffers;
		m_ppd3dTextureUploadBuffers = NULL;
	}
}

void CTexture::LoadTextureFromFile(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, wchar_t* pszFileName, UINT nResourceType, UINT nIndex)
{
	m_pnResourceTypes[nIndex] = nResourceType;
	m_ppd3dTextures[nIndex] = ::CreateTextureResourceFromDDSFile(pd3dDevice, pd3dCommandList, pszFileName, &m_ppd3dTextureUploadBuffers[nIndex], D3D12_RESOURCE_STATE_GENERIC_READ/*D3D12_RESOURCE_STATE_PIXEL_SHADER_RESOURCE*/);
}

void CTexture::LoadBuffer(ID3D12Device* pd3dDevice, ID3D12GraphicsCommandList* pd3dCommandList, void* pData, UINT nElements, UINT nStride, DXGI_FORMAT ndxgiFormat, UINT nIndex)
{
	m_pnResourceTypes[nIndex] = RESOURCE_BUFFER;
	m_pdxgiBufferFormats[nIndex] = ndxgiFormat;
	m_pnBufferElements[nIndex] = nElements;
	m_ppd3dTextures[nIndex] = ::CreateBufferResource(pd3dDevice, pd3dCommandList, pData, nElements * nStride, D3D12_HEAP_TYPE_DEFAULT, D3D12_RESOURCE_STATE_GENERIC_READ, &m_ppd3dTextureUploadBuffers[nIndex]);
}

D3D12_SHADER_RESOURCE_VIEW_DESC CTexture::GetShaderResourceViewDesc(int nIndex)
{
	ID3D12Resource* pShaderResource = GetResource(nIndex);
	D3D12_RESOURCE_DESC d3dResourceDesc = pShaderResource->GetDesc();

	D3D12_SHADER_RESOURCE_VIEW_DESC d3dShaderResourceViewDesc;
	d3dShaderResourceViewDesc.Shader4ComponentMapping = D3D12_DEFAULT_SHADER_4_COMPONENT_MAPPING;

	int nTextureType = GetTextureType(nIndex);
	switch (nTextureType)
	{
	case RESOURCE_TEXTURE2D: //(d3dResourceDesc.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D)(d3dResourceDesc.DepthOrArraySize == 1)
	case RESOURCE_TEXTURE2D_ARRAY: //[]
		d3dShaderResourceViewDesc.Format = d3dResourceDesc.Format;
		d3dShaderResourceViewDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2D;
		d3dShaderResourceViewDesc.Texture2D.MipLevels = -1;
		d3dShaderResourceViewDesc.Texture2D.MostDetailedMip = 0;
		d3dShaderResourceViewDesc.Texture2D.PlaneSlice = 0;
		d3dShaderResourceViewDesc.Texture2D.ResourceMinLODClamp = 0.0f;
		break;
	case RESOURCE_TEXTURE2DARRAY: //(d3dResourceDesc.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D)(d3dResourceDesc.DepthOrArraySize != 1)
		d3dShaderResourceViewDesc.Format = d3dResourceDesc.Format;
		d3dShaderResourceViewDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURE2DARRAY;
		d3dShaderResourceViewDesc.Texture2DArray.MipLevels = -1;
		d3dShaderResourceViewDesc.Texture2DArray.MostDetailedMip = 0;
		d3dShaderResourceViewDesc.Texture2DArray.PlaneSlice = 0;
		d3dShaderResourceViewDesc.Texture2DArray.ResourceMinLODClamp = 0.0f;
		d3dShaderResourceViewDesc.Texture2DArray.FirstArraySlice = 0;
		d3dShaderResourceViewDesc.Texture2DArray.ArraySize = d3dResourceDesc.DepthOrArraySize;
		break;
	case RESOURCE_TEXTURE_CUBE: //(d3dResourceDesc.Dimension == D3D12_RESOURCE_DIMENSION_TEXTURE2D)(d3dResourceDesc.DepthOrArraySize == 6)
		d3dShaderResourceViewDesc.Format = d3dResourceDesc.Format;
		d3dShaderResourceViewDesc.ViewDimension = D3D12_SRV_DIMENSION_TEXTURECUBE;
		d3dShaderResourceViewDesc.TextureCube.MipLevels = -1;
		d3dShaderResourceViewDesc.TextureCube.MostDetailedMip = 0;
		d3dShaderResourceViewDesc.TextureCube.ResourceMinLODClamp = 0.0f;
		break;
	case RESOURCE_BUFFER: //(d3dResourceDesc.Dimension == D3D12_RESOURCE_DIMENSION_BUFFER)
		d3dShaderResourceViewDesc.Format = m_pdxgiBufferFormats[nIndex];
		d3dShaderResourceViewDesc.ViewDimension = D3D12_SRV_DIMENSION_BUFFER;
		d3dShaderResourceViewDesc.Buffer.FirstElement = 0;
		d3dShaderResourceViewDesc.Buffer.NumElements = m_pnBufferElements[nIndex];
		d3dShaderResourceViewDesc.Buffer.StructureByteStride = 0;
		d3dShaderResourceViewDesc.Buffer.Flags = D3D12_BUFFER_SRV_FLAG_NONE;
		break;
	}

	return(d3dShaderResourceViewDesc);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
CMaterial::CMaterial()
{
}

CMaterial::~CMaterial()
{
	if (m_pTexture) m_pTexture->Release();
	if (m_pShader) m_pShader->Release();
}

void CMaterial::SetTexture(CTexture *pTexture)
{
	if (m_pTexture) m_pTexture->Release();
	m_pTexture = pTexture;
	if (m_pTexture) m_pTexture->AddRef();
}

void CMaterial::SetShader(CShader *pShader)
{
	if (m_pShader) m_pShader->Release();
	m_pShader = pShader;
	if (m_pShader) m_pShader->AddRef();
}

void CMaterial::UpdateShaderVariables(ID3D12GraphicsCommandList *pd3dCommandList)
{
	if (m_pTexture) m_pTexture->UpdateShaderVariables(pd3dCommandList);
}

void CMaterial::ReleaseShaderVariables()
{
	if (m_pShader) m_pShader->ReleaseShaderVariables();
	if (m_pTexture) m_pTexture->ReleaseShaderVariables();
}

void CMaterial::ReleaseUploadBuffers()
{
	if (m_pTexture) m_pTexture->ReleaseUploadBuffers();
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//
CGameObject::CGameObject(int nMeshes, int nMaterials)
{
	m_xmf4x4ToParentTransform = Matrix4x4::Identity();
	m_xmf4x4World = Matrix4x4::Identity();

	m_nMeshes = nMeshes;
	m_ppMeshes = NULL;
	if (m_nMeshes > 0)
	{
		m_ppMeshes = new CMesh*[m_nMeshes];
		for (int i = 0; i < m_nMeshes; i++)	m_ppMeshes[i] = NULL;
	}

	m_nMaterials = nMaterials;
	m_ppMaterials = NULL;
	if (m_nMaterials > 0)
	{
		m_ppMaterials = new CMaterial*[m_nMaterials];
		for (int i = 0; i < m_nMaterials; i++) m_ppMaterials[i] = NULL;
	}
}

CGameObject::~CGameObject()
{
	ReleaseShaderVariables();
	ReleaseMaterials();

	if (m_ppMeshes)
	{
		for (int i = 0; i < m_nMeshes; i++)
		{
			if (m_ppMeshes[i]) m_ppMeshes[i]->Release();
			m_ppMeshes[i] = NULL;
		}
		delete[] m_ppMeshes;
	}

	if (m_pSibling) delete m_pSibling;
	if (m_pChild) delete m_pChild;
}

void CGameObject::ResizeMeshes(int nMeshes)
{
	CMesh **ppMeshes = NULL;
	if (nMeshes > 0)
	{
		ppMeshes = new CMesh*[nMeshes];
		for (int i = 0; i < nMeshes; i++) ppMeshes[i] = NULL;
	}

	if (m_ppMeshes)
	{
		for (int i = 0; i < m_nMeshes; i++) ppMeshes[i] = m_ppMeshes[i];
		delete[] m_ppMeshes;
	}

	m_nMeshes = nMeshes;
	m_ppMeshes = ppMeshes;
}

void CGameObject::ReleaseMaterials()
{
	if (m_ppMaterials)
	{
		for (int i = 0; i < m_nMaterials; i++) if (m_ppMaterials[i]) m_ppMaterials[i]->Release();
		delete[] m_ppMaterials;
	}
}

void CGameObject::ResizeMaterials(int nMaterials)
{
	if (m_nMaterials != nMaterials)
	{
		if (!nMaterials)
		{
			ReleaseMaterials();
		}
		else
		{
			CMaterial **ppMaterials = NULL;
			ppMaterials = new CMaterial*[nMaterials];
			for (int i = 0; i < nMaterials; i++) ppMaterials[i] = NULL;

			if (m_ppMaterials)
			{
				for (int i = 0; i < m_nMaterials; i++) ppMaterials[i] = m_ppMaterials[i];
				delete[] m_ppMaterials;
			}

			m_nMaterials = nMaterials;
			m_ppMaterials = ppMaterials;
		}
	}
}

void CGameObject::SetChild(CGameObject *pChild)
{
	if (m_pChild)
	{
		if (pChild) pChild->m_pSibling = m_pChild->m_pSibling;
		m_pChild->m_pSibling = pChild;
	}
	else
	{
		m_pChild = pChild;
	}
	if (pChild) pChild->m_pParent = this;
}

void CGameObject::SetMesh(int nIndex, CMesh *pMesh)
{
	if ((m_nMeshes == 0) && (m_ppMeshes == NULL)) ResizeMeshes(nIndex + 1);
	if (m_ppMeshes)
	{
		if (m_ppMeshes[nIndex]) m_ppMeshes[nIndex]->Release();
		m_ppMeshes[nIndex] = pMesh;
		if (pMesh) pMesh->AddRef();
	}
}

void CGameObject::SetShader(int nIndex, CShader *pShader)
{
	if (nIndex < m_nMaterials)
	{
		if (m_ppMaterials) m_ppMaterials[nIndex]->SetShader(pShader);
	}
	else
	{
		ResizeMaterials(nIndex + 1);
		CMaterial *pMaterial = new CMaterial();
		pMaterial->SetShader(pShader);
		SetMaterial(nIndex, pMaterial);
	}
}

void CGameObject::SetMaterial(int nIndex, CMaterial *pMaterial)
{
	if ((nIndex < m_nMaterials) && (m_ppMaterials[nIndex] != pMaterial))
	{
		if (m_ppMaterials[nIndex]) m_ppMaterials[nIndex]->Release();
		m_ppMaterials[nIndex] = pMaterial;
		if (m_ppMaterials[nIndex]) m_ppMaterials[nIndex]->AddRef();
	}
}

void CGameObject::Clone(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature, CShader *pRootShader, CGameObject *pCloneObject, CGameObject *pParent, CGameObject *pRootFrame)
{
	_tcscpy_s(pCloneObject->m_pstrFrameName, 64, m_pstrFrameName);
	pCloneObject->m_bActive = m_bActive;

	for (int i = 0; i < m_nMeshes; i++) pCloneObject->SetMesh(i, m_ppMeshes[i]);

	pCloneObject->m_xmf4x4ToParentTransform = m_xmf4x4ToParentTransform;
	//pCloneObject->m_xmf4x4ToRootTransform = m_xmf4x4ToRootTransform;
	pCloneObject->m_xmf4x4World = m_xmf4x4World;

	if (m_nMaterials > 0)
	{
		pCloneObject->ResizeMaterials(m_nMaterials);

		for (int m = 0; m < m_nMaterials; m++)
		{
			CMaterial *pMaterial = new CMaterial();
			pMaterial->SetShader(pRootShader);

			pMaterial->m_xmf4Albedo = m_ppMaterials[m]->m_xmf4Albedo;
			pMaterial->m_nReflection = m_ppMaterials[m]->m_nReflection;

			pCloneObject->SetMaterial(m, pMaterial);

			if (m_ppMaterials[m]->m_pTexture)
			{
				CTexture *pTexture = pRootFrame->FindTexture(m_ppMaterials[m]->m_pTexture->m_ppstrTextureNames[0]);
				if (!pTexture)
				{
					pTexture = new CTexture(m_ppMaterials[m]->m_pTexture->m_nTextures, m_ppMaterials[m]->m_pTexture->m_nTextureType, 0, 1);
					for (int i = 0; i < m_ppMaterials[m]->m_pTexture->m_nTextures; i++)
					{
						pTexture->m_ppd3dTextures[i] = m_ppMaterials[m]->m_pTexture->m_ppd3dTextures[i];
						pTexture->m_ppd3dTextures[i]->AddRef();

						pTexture->SetTextureName(i, m_ppMaterials[m]->m_pTexture->m_ppstrTextureNames[i]);
					}

					if (pRootShader) pRootShader->CreateShaderResourceViews(pd3dDevice, pTexture, 0, ROOT_PARAMETER_TEXTURE);
				}
				pMaterial->SetTexture(pTexture);
			}

			UINT ncbElementBytes = ((sizeof(CB_GAMEOBJECT_INFO) + 255) & ~255);
			ID3D12Resource *pd3dcbResource = pCloneObject->CreateShaderVariables(pd3dDevice, pd3dCommandList);

			D3D12_GPU_DESCRIPTOR_HANDLE d3dGpuDescriptorHandle = pRootShader->CreateConstantBufferViews(pd3dDevice, 1, pd3dcbResource, ncbElementBytes);
			pCloneObject->SetCbvGPUDescriptorHandle(d3dGpuDescriptorHandle);
		}
	}

	if (m_pSibling)
	{
		CGameObject *pSiblingClone = new CGameObject(m_pSibling->m_nMeshes);
		if (pParent) pParent->SetChild(pSiblingClone);
		m_pSibling->Clone(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pRootShader, pSiblingClone, pParent, pRootFrame);
	}
	if (m_pChild)
	{
		CGameObject *pChildClone = new CGameObject(m_pChild->m_nMeshes);
		pCloneObject->SetChild(pChildClone);
		m_pChild->Clone(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pRootShader, pChildClone, pCloneObject, pRootFrame);
	}
}

ID3D12Resource *CGameObject::CreateShaderVariables(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList)
{
	UINT ncbElementBytes = ((sizeof(CB_GAMEOBJECT_INFO) + 255) & ~255); //256�� ���
	m_pd3dcbGameObject = ::CreateBufferResource(pd3dDevice, pd3dCommandList, NULL, ncbElementBytes, D3D12_HEAP_TYPE_UPLOAD, D3D12_RESOURCE_STATE_VERTEX_AND_CONSTANT_BUFFER, NULL);

	m_pd3dcbGameObject->Map(0, NULL, (void **)&m_pcbMappedGameObject);

	return(m_pd3dcbGameObject);
}

void CGameObject::ReleaseShaderVariables()
{
	if (m_pd3dcbGameObject)
	{
		m_pd3dcbGameObject->Unmap(0, NULL);
		m_pd3dcbGameObject->Release();
	}
	for (int m = 0; m < m_nMaterials; m++) if (m_ppMaterials[m]) m_ppMaterials[m]->ReleaseShaderVariables();
}

void CGameObject::UpdateShaderVariable(ID3D12GraphicsCommandList *pd3dCommandList, XMFLOAT4X4 *pxmf4x4World)
{
	if (m_pcbMappedGameObject) XMStoreFloat4x4(&m_pcbMappedGameObject->m_xmf4x4World, XMMatrixTranspose(XMLoadFloat4x4(pxmf4x4World)));
}

void CGameObject::UpdateShaderVariable(ID3D12GraphicsCommandList *pd3dCommandList, int nReflection)
{
	if (m_pcbMappedGameObject) m_pcbMappedGameObject->m_nMaterial = nReflection;
}

void CGameObject::Animate(float fTimeElapsed)
{
	//if (m_ppMeshes && (m_nMeshes > 0))
	//{
	//	for (int i = 0; i < m_nMeshes; i++)
	//	{
	//		if(m_ppMeshes[i]) m_ppMeshes[i]->UpdateAnimationSet(pd3dCommandList, 0, 0.0f);
	//	}
	//}

	if (m_pSibling) m_pSibling->Animate(fTimeElapsed);
	if (m_pChild) m_pChild->Animate(fTimeElapsed);
}

void CGameObject::SetRootParameter(ID3D12GraphicsCommandList *pd3dCommandList)
{
	pd3dCommandList->SetGraphicsRootDescriptorTable(ROOT_PARAMETER_OBJECT, m_d3dCbvGameObjectGPUDescriptorHandle);
}

void CGameObject::OnPrepareRender()
{
}

void CGameObject::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera)
{
	if (m_bActive)
	{
		OnPrepareRender();

		if (m_nMaterials > 0)
		{
			UpdateShaderVariable(pd3dCommandList, &m_xmf4x4World);
			for (int m = 0; m < m_nMaterials; m++)
			{
				if (m_ppMaterials[m])
				{
					if (m_ppMaterials[m]->m_pShader)
					{
						m_ppMaterials[m]->m_pShader->Render(pd3dCommandList, pCamera);
						UpdateShaderVariable(pd3dCommandList, m_ppMaterials[m]->m_nReflection);
					}
					if (m_ppMaterials[m]->m_pTexture)
					{
						m_ppMaterials[m]->m_pTexture->UpdateShaderVariables(pd3dCommandList);
					}
				}

				if (m_ppMeshes && (m_nMeshes > 0))
				{
					SetRootParameter(pd3dCommandList);
					for (int i = 0; i < m_nMeshes; i++)
					{
						if (m_ppMeshes[i])
						{
							m_ppMeshes[i]->UpdateAnimationSet(pd3dCommandList, m_nAnimationSet, 0.0f);
							m_ppMeshes[i]->OnPreRender(pd3dCommandList);
							m_ppMeshes[i]->Render(pd3dCommandList, m);
						}
					}
				}
			}
		}
	}

	if (m_pSibling) m_pSibling->Render(pd3dCommandList, pCamera);
	if (m_pChild) m_pChild->Render(pd3dCommandList, pCamera);
}

void CGameObject::ReleaseUploadBuffers()
{
	if (m_ppMeshes)
	{
		for (int i = 0; i < m_nMeshes; i++)
		{
			if (m_ppMeshes[i]) m_ppMeshes[i]->ReleaseUploadBuffers();
		}
	}

	for (int m = 0; m < m_nMaterials; m++)
	{
		if (m_ppMaterials[m]) m_ppMaterials[m]->ReleaseUploadBuffers();
	}

	if (m_pSibling) m_pSibling->ReleaseUploadBuffers();
	if (m_pChild) m_pChild->ReleaseUploadBuffers();
}

void CGameObject::UpdateTransformHierarchy(XMFLOAT4X4 *pxmf4x4Parent)
{
	m_xmf4x4World = (pxmf4x4Parent) ? Matrix4x4::Multiply(m_xmf4x4ToParentTransform, *pxmf4x4Parent) : m_xmf4x4ToParentTransform;

	if (m_pSibling) m_pSibling->UpdateTransformHierarchy(pxmf4x4Parent);
	if (m_pChild) m_pChild->UpdateTransformHierarchy(&m_xmf4x4World);
}

CGameObject *CGameObject::FindFrame(_TCHAR *pstrFrameName)
{
	CGameObject *pFrameObject = NULL;
	if (!_tcscmp(m_pstrFrameName, pstrFrameName)) return(this);

	if (m_pSibling) if (pFrameObject = m_pSibling->FindFrame(pstrFrameName)) return(pFrameObject);
	if (m_pChild) if (pFrameObject = m_pChild->FindFrame(pstrFrameName)) return(pFrameObject);

	return(NULL);
}

CMesh *CGameObject::GetSkinnedMesh()
{
	for (int i = 0; i < m_nMeshes; i++)
	{
		if (m_ppMeshes[i]->m_bSkinnedMesh) return(m_ppMeshes[i]);
	}

	return(NULL);
}

CTexture *CGameObject::FindTexture(_TCHAR *pstrTextureName)
{
	CTexture *pTexture = NULL;
	for (int m = 0; m < m_nMaterials; m++)
	{
		if (m_ppMaterials[m])
		{
			pTexture = m_ppMaterials[m]->m_pTexture;
			if (pTexture)
			{
				int nTextures = pTexture->GetTextures();
				for (int i = 0; i < nTextures; i++) if (!_tcscmp(pTexture->m_ppstrTextureNames[i], pstrTextureName)) return(pTexture);
			}
		}
	}

	if (m_pSibling) if (pTexture = m_pSibling->FindTexture(pstrTextureName)) return(pTexture);
	if (m_pChild) if (pTexture = m_pChild->FindTexture(pstrTextureName)) return(pTexture);

	return(NULL);
}

void CGameObject::SetPosition(float x, float y, float z)
{
	m_xmf4x4ToParentTransform._41 = x;
	m_xmf4x4ToParentTransform._42 = y;
	m_xmf4x4ToParentTransform._43 = z;
}

void CGameObject::SetPosition(XMFLOAT3 xmf3Position)
{
	SetPosition(xmf3Position.x, xmf3Position.y, xmf3Position.z);
}

void CGameObject::SetLocalPosition(XMFLOAT3 xmf3Position)
{
	XMMATRIX mtxTranslation = XMMatrixTranslation(xmf3Position.x, xmf3Position.y, xmf3Position.z);
	m_xmf4x4ToParentTransform = Matrix4x4::Multiply(m_xmf4x4ToParentTransform, mtxTranslation);
}

void CGameObject::SetScale(float x, float y, float z)
{
	XMMATRIX mtxScale = XMMatrixScaling(x, y, z);
	m_xmf4x4ToParentTransform = Matrix4x4::Multiply(mtxScale, m_xmf4x4ToParentTransform);
}

void CGameObject::SetLocalScale(float x, float y, float z)
{
}

XMFLOAT3 CGameObject::GetPosition()
{
	return(XMFLOAT3(m_xmf4x4World._41, m_xmf4x4World._42, m_xmf4x4World._43));
}

XMFLOAT3 CGameObject::GetLook()
{
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._31, m_xmf4x4World._32, m_xmf4x4World._33)));
}

XMFLOAT3 CGameObject::GetUp()
{
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._21, m_xmf4x4World._22, m_xmf4x4World._23)));
}

XMFLOAT3 CGameObject::GetRight()
{
	return(Vector3::Normalize(XMFLOAT3(m_xmf4x4World._11, m_xmf4x4World._12, m_xmf4x4World._13)));
}

void CGameObject::MoveStrafe(float fDistance)
{
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Right = GetRight();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Right, fDistance);
	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::MoveUp(float fDistance)
{
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Up = GetUp();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Up, fDistance);
	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::MoveForward(float fDistance)
{
	XMFLOAT3 xmf3Position = GetPosition();
	XMFLOAT3 xmf3Look = GetLook();
	xmf3Position = Vector3::Add(xmf3Position, xmf3Look, fDistance);
	CGameObject::SetPosition(xmf3Position);
}

void CGameObject::Rotate(float fPitch, float fYaw, float fRoll)
{
	XMMATRIX mtxRotate = XMMatrixRotationRollPitchYaw(XMConvertToRadians(fPitch), XMConvertToRadians(fYaw), XMConvertToRadians(fRoll));
	m_xmf4x4ToParentTransform = Matrix4x4::Multiply(mtxRotate, m_xmf4x4ToParentTransform);
}

void CGameObject::Rotate(XMFLOAT3 *pxmf3Axis, float fAngle)
{
	XMMATRIX mtxRotate = XMMatrixRotationAxis(XMLoadFloat3(pxmf3Axis), XMConvertToRadians(fAngle));
	m_xmf4x4ToParentTransform = Matrix4x4::Multiply(mtxRotate, m_xmf4x4ToParentTransform);
}

void CGameObject::Rotate(XMFLOAT4 *pxmf4Quaternion)
{
	XMMATRIX mtxRotate = XMMatrixRotationQuaternion(XMLoadFloat4(pxmf4Quaternion));
	m_xmf4x4ToParentTransform = Matrix4x4::Multiply(mtxRotate, m_xmf4x4ToParentTransform);
}

#define _WITH_DEBUG_FRAME_HIERARCHY

void CGameObject::LoadFrameHierarchyFromFile(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature, CShader *pRootShader, CGameObject *pRootFrame, bool bHasAnimation, wifstream& InFile)
{
	XMFLOAT3 *pxmf3Positions = NULL, *pxmf3Normals = NULL;
	XMFLOAT2 *pxmf3TextureCoords0 = NULL, *pxmf3TextureCoords1 = NULL;
	UINT *pnIndices = NULL, *pnSubsetStarts = NULL, *pnSubSetIndices = NULL, **ppnSubsetIndices = NULL;

	TCHAR pstrTransformName[64] ={ '\0' };
	TCHAR pstrMeshName[64] ={ '\0' };
	TCHAR pstrToken[64] ={ '\0' };
	TCHAR pstrDebug[128] ={ '\0' };

	XMFLOAT4 *pxmf4MaterialAlbedos = NULL;
	TCHAR **ppstrAlbedoTextureNames = NULL, **ppstrEmissionTextureNames = NULL;
	int *pnAlbedoTextures = NULL, *pnEmissionTextures = NULL;

	int nChilds = 0, nVertices = 0, nNormals = 0, nTextureCoords0 = 0, nTextureCoords1 = 0, nIndices = 0, nMaterials = 0, nTextures = 0, nFrame = 0, nMaterial = 0, nSubsets = 0;

	bool bIsSkinnedMesh = false;
	TCHAR pstrSkinnedMeshName[64] ={ '\0' };
	TCHAR **ppstrSkinningBoneNames = NULL;
	int nSkinningBones = 0, nSkinningBoneOffsets = 0, nSkinningBoneWeights = 0;
	XMFLOAT4 *pxmf4SkinningBoneWeights = NULL;
	XMUINT4 *pxmu4SkinningBoneIndices = NULL;
	XMFLOAT4X4 *pxmf4x4MeshToBoneOffsets = NULL;

	for ( ; ; )
	{
		InFile >> pstrToken;
		if (!InFile) break;

		if (!_tcscmp(pstrToken, _T("FrameName:")))
		{
			InFile >> nFrame;
			InFile >> m_pstrFrameName;

			nChilds = nVertices = nNormals = nTextureCoords0 = nTextureCoords1 = nIndices = nTextures = nSubsets = nMaterial = 0;
			pxmf3Positions = pxmf3Normals = NULL;
			pxmf3TextureCoords0 = pxmf3TextureCoords1 = NULL;
			pxmf4MaterialAlbedos = NULL; 
			ppstrAlbedoTextureNames = ppstrEmissionTextureNames = NULL;
			pnAlbedoTextures = pnEmissionTextures = NULL;
			pnIndices = NULL;
			pnSubsetStarts = pnSubSetIndices = NULL;
			ppnSubsetIndices = NULL;

			pxmf4SkinningBoneWeights = NULL;
			pxmu4SkinningBoneIndices = NULL;
			nSkinningBones = nSkinningBoneOffsets = nSkinningBoneWeights = 0;
			ppstrSkinningBoneNames = NULL;
			pxmf4x4MeshToBoneOffsets = NULL;
			bIsSkinnedMesh = false;
		}
		else if (!_tcscmp(pstrToken, _T("Transform:")))
		{
			InFile >> pstrTransformName;

			InFile >> m_xmf4x4ToParentTransform._11 >> m_xmf4x4ToParentTransform._12 >> m_xmf4x4ToParentTransform._13 >> m_xmf4x4ToParentTransform._14;
			InFile >> m_xmf4x4ToParentTransform._21 >> m_xmf4x4ToParentTransform._22 >> m_xmf4x4ToParentTransform._23 >> m_xmf4x4ToParentTransform._24;
			InFile >> m_xmf4x4ToParentTransform._31 >> m_xmf4x4ToParentTransform._32 >> m_xmf4x4ToParentTransform._33 >> m_xmf4x4ToParentTransform._34;
			InFile >> m_xmf4x4ToParentTransform._41 >> m_xmf4x4ToParentTransform._42 >> m_xmf4x4ToParentTransform._43 >> m_xmf4x4ToParentTransform._44;
		}
		else if (!_tcscmp(pstrToken, _T("MeshName:")))
		{
			InFile >> pstrMeshName;
			bIsSkinnedMesh = false;
		}
		else if (!_tcscmp(pstrToken, _T("SkinnedMeshName:")))
		{
			InFile >> pstrSkinnedMeshName;
			bIsSkinnedMesh = true;
		}
		else if (!_tcscmp(pstrToken, _T("Vertices:")))
		{
			InFile >> nVertices;
			pxmf3Positions = new XMFLOAT3[nVertices];
			for (int i = 0; i < nVertices; i++)
			{
				InFile >> pxmf3Positions[i].x >> pxmf3Positions[i].y >> pxmf3Positions[i].z;
			}
		}
		else if (!_tcscmp(pstrToken, _T("Normals:")))
		{
			InFile >> nNormals;
			pxmf3Normals = new XMFLOAT3[nNormals];
			for (int i = 0; i < nNormals; i++)
			{
				InFile >> pxmf3Normals[i].x >> pxmf3Normals[i].y >> pxmf3Normals[i].z;
			}
		}
		else if (!_tcscmp(pstrToken, _T("TextureCoordinates0:")))
		{
			InFile >> nTextureCoords0;
			pxmf3TextureCoords0 = new XMFLOAT2[nTextureCoords0];
			for (int i = 0; i < nTextureCoords0; i++)
			{
				InFile >> pxmf3TextureCoords0[i].x >> pxmf3TextureCoords0[i].y;
			}
		}
		else if (!_tcscmp(pstrToken, _T("TextureCoordinates1:")))
		{
			InFile >> nTextureCoords1;
			pxmf3TextureCoords1 = new XMFLOAT2[nTextureCoords1];
			for (int i = 0; i < nTextureCoords1; i++)
			{
				InFile >> pxmf3TextureCoords1[i].x >> pxmf3TextureCoords1[i].y;
			}
		}
		else if (!_tcscmp(pstrToken, _T("Indices:")))
		{
			InFile >> nIndices;
			pnIndices = new UINT[nIndices];
			for (int i = 0; i < nIndices; i++)
			{
				InFile >> pnIndices[i];
			}
		}
		else if (!_tcscmp(pstrToken, _T("SubMeshes:")))
		{
			InFile >> nSubsets;
			if (nSubsets > 0)
			{
				ppnSubsetIndices = new UINT*[nSubsets];
				pnSubsetStarts = new UINT[nSubsets];
				pnSubSetIndices = new UINT[nSubsets];
				int nSubset;
				for (int i = 0; i < nSubsets; i++)
				{
					InFile >> pstrToken; //SubMesh:
					InFile >> nSubset; //SubSet Index:
					InFile >> pnSubsetStarts[i] >> pnSubSetIndices[i];
					ppnSubsetIndices[i] = new UINT[pnSubSetIndices[i]];
					for (UINT j = 0; j < pnSubSetIndices[i]; j++)
					{
						InFile >> ppnSubsetIndices[i][j];
					}
				}
			}
		}
		else if (!_tcscmp(pstrToken, _T("Materials:")))
		{
			InFile >> nMaterials;
			if (nMaterials > 0)
			{
				pxmf4MaterialAlbedos = new XMFLOAT4[nMaterials];
				ppstrAlbedoTextureNames = new _TCHAR*[nMaterials];
				ppstrEmissionTextureNames = new _TCHAR*[nMaterials];
				pnAlbedoTextures = new int[nMaterials];
				pnEmissionTextures = new int[nMaterials];
			}
		}
		else if (!_tcscmp(pstrToken, _T("Material:")))
		{
			InFile >> nMaterial;
			pnAlbedoTextures[nMaterial] = pnEmissionTextures[nMaterial] = 0;
			ppstrAlbedoTextureNames[nMaterial] = ppstrEmissionTextureNames[nMaterial] = NULL;
		}
		else if (!_tcscmp(pstrToken, _T("AlbedoColor:")))
		{
			InFile >> pxmf4MaterialAlbedos[nMaterial].x >> pxmf4MaterialAlbedos[nMaterial].y >> pxmf4MaterialAlbedos[nMaterial].z >> pxmf4MaterialAlbedos[nMaterial].w;
		}
		else if (!_tcscmp(pstrToken, _T("AlbedoTextureName:")))
		{
			nTextures++;
			pnAlbedoTextures[nMaterial]++;
			ppstrAlbedoTextureNames[nMaterial] = new _TCHAR[64];
			InFile >> ppstrAlbedoTextureNames[nMaterial];
		}
		else if (!_tcscmp(pstrToken, _T("EmissionTextureName:")))
		{
			nTextures++;
			pnEmissionTextures[nMaterial]++;
			ppstrEmissionTextureNames[nMaterial] = new _TCHAR[64];
			InFile >> ppstrEmissionTextureNames[nMaterial];
		}
		else if (!_tcscmp(pstrToken, _T("BoneNames:")))
		{
			InFile >> nSkinningBones;

			ppstrSkinningBoneNames = new TCHAR*[nSkinningBones];
			for (int i = 0; i < nSkinningBones; i++)
			{
				ppstrSkinningBoneNames[i] = new TCHAR[64];
				InFile >> ppstrSkinningBoneNames[i];
			}
		}
		else if (!_tcscmp(pstrToken, _T("BoneOffsets:")))
		{
			InFile >> nSkinningBoneOffsets; //(nSkinningBoneOffsets == nSkinningBones)

			pxmf4x4MeshToBoneOffsets = new XMFLOAT4X4[nSkinningBoneOffsets];
			for (int i = 0; i < nSkinningBones; i++)
			{
				InFile >> pxmf4x4MeshToBoneOffsets[i]._11 >> pxmf4x4MeshToBoneOffsets[i]._12 >> pxmf4x4MeshToBoneOffsets[i]._13 >> pxmf4x4MeshToBoneOffsets[i]._14;
				InFile >> pxmf4x4MeshToBoneOffsets[i]._21 >> pxmf4x4MeshToBoneOffsets[i]._22 >> pxmf4x4MeshToBoneOffsets[i]._23 >> pxmf4x4MeshToBoneOffsets[i]._24;
				InFile >> pxmf4x4MeshToBoneOffsets[i]._31 >> pxmf4x4MeshToBoneOffsets[i]._32 >> pxmf4x4MeshToBoneOffsets[i]._33 >> pxmf4x4MeshToBoneOffsets[i]._34;
				InFile >> pxmf4x4MeshToBoneOffsets[i]._41 >> pxmf4x4MeshToBoneOffsets[i]._42 >> pxmf4x4MeshToBoneOffsets[i]._43 >> pxmf4x4MeshToBoneOffsets[i]._44;
			}
		}
		else if (!_tcscmp(pstrToken, _T("BoneWeights:")))
		{
			InFile >> nSkinningBoneWeights; //(nSkinningBoneWeights == nVertices)

			pxmu4SkinningBoneIndices = new XMUINT4[nSkinningBoneWeights];
			pxmf4SkinningBoneWeights = new XMFLOAT4[nSkinningBoneWeights];
			for (int i = 0; i < nSkinningBoneWeights; i++)
			{
				InFile >> pxmu4SkinningBoneIndices[i].x >> pxmf4SkinningBoneWeights[i].x >> pxmu4SkinningBoneIndices[i].y >> pxmf4SkinningBoneWeights[i].y >> pxmu4SkinningBoneIndices[i].z >> pxmf4SkinningBoneWeights[i].z >> pxmu4SkinningBoneIndices[i].w >> pxmf4SkinningBoneWeights[i].w;
			}
		}
		else if (!_tcscmp(pstrToken, _T("Children:")))
		{
			InFile >> nChilds;
			if (nChilds > 0)
			{
				for (int i = 0; i < nChilds; i++)
				{
					CGameObject *pChild = new CGameObject(0, 1);
					pChild->LoadFrameHierarchyFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pRootShader, pRootFrame, bHasAnimation, InFile);
					SetChild(pChild);
#ifdef _WITH_DEBUG_FRAME_HIERARCHY
					_stprintf_s(pstrDebug, 128, _T("(Frame: %p) (Parent: %p)\n"), pChild, this);
					OutputDebugString(pstrDebug);
#endif
				}
			}
		}
		else if (!_tcscmp(pstrToken, _T("EndOfFrame")))
		{
			CMesh *pMesh = NULL;

			bool bHasVertex = (nVertices > 0);
			bool bHasNormal = (nNormals > 0);
			bool bHasTexture = ((nTextureCoords0 > 0) || (nTextureCoords1 > 0)) && (nTextures > 0);
			bool bHasNormalTexture = (bHasNormal && bHasTexture);

			if (bHasVertex)
			{
				CShader *pShader = pRootShader;

				ResizeMaterials(nMaterials);

				for (int m = 0; m < nMaterials; m++)
				{
					CMaterial *pMaterial = m_ppMaterials[m];

					if (m_pParent || !pMaterial)
					{
						if (bHasNormalTexture)
						{
							if (bIsSkinnedMesh) pShader = new CSkinnedIlluminatedTexturedShader();
							else pShader = new CIlluminatedTexturedShader();
						}
						else if (bHasNormal)
						{
							if (bIsSkinnedMesh) pShader = new CSkinnedIlluminatedShader();
							else pShader = new CIlluminatedShader();
						}
						else if (bHasTexture)
						{
//							if (bIsSkinnedMesh) pShader = new CSkinnedTexturedShader();
							pShader = new CTexturedShader();
						}
						else pShader = new CShader();

						pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
						pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
						//pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 5, 2); //Child: 4, Texture: 2

						pMaterial = new CMaterial();
						pMaterial->SetShader(pShader);
					}
					pMaterial->m_xmf4Albedo = pxmf4MaterialAlbedos[m];

					if (bHasTexture)
					{
						CTexture *pAlbedoTexture = NULL, *pEmissionTexture = NULL, *pTexture = NULL;
						//if (ppstrAlbedoTextureNames[m]) pAlbedoTexture = pRootFrame->FindTexture(ppstrAlbedoTextureNames[m]);
						//if (ppstrEmissionTextureNames[m]) pEmissionTexture = pRootFrame->FindTexture(ppstrEmissionTextureNames[m]);
						if ((pnAlbedoTextures[m] >0) || (pnEmissionTextures[m] > 0))
						{
							pTexture = new CTexture(pnAlbedoTextures[m] + pnEmissionTextures[m], RESOURCE_TEXTURE2D, 0, 1);

							int nIndex = 0;
							if (pnAlbedoTextures[m] > 0)
							{
								TCHAR pstrPathName[128] ={ '\0' };
								_tcscpy_s(pstrPathName, 128, _T("../Assets/Model/"));
								_tcscat_s(pstrPathName, 128, ppstrAlbedoTextureNames[m]);
								_tcscat_s(pstrPathName, 128, _T(".dds"));

								pTexture->LoadTextureFromFile(pd3dDevice, pd3dCommandList, pstrPathName, RESOURCE_TEXTURE2D, 0);
								pTexture->SetTextureName(nIndex++, ppstrAlbedoTextureNames[m]);
							}
							if (pnEmissionTextures[m] > 0)
							{
								TCHAR pstrPathName[128] ={ '\0' };
								_tcscpy_s(pstrPathName, 128, _T("../Assets/Model/"));
								_tcscat_s(pstrPathName, 128, ppstrEmissionTextureNames[m]);
								_tcscat_s(pstrPathName, 128, _T(".dds"));

								pTexture->LoadTextureFromFile(pd3dDevice, pd3dCommandList, pstrPathName, RESOURCE_TEXTURE2D, 1);
								pTexture->SetTextureName(nIndex++, ppstrEmissionTextureNames[m]);
							}

							if (pRootShader) pRootShader->CreateShaderResourceViews(pd3dDevice, pTexture, 0, ROOT_PARAMETER_TEXTURE);
						}
						if (pTexture) pMaterial->SetTexture(pTexture);
					}

					SetMaterial(m, pMaterial);
				}

				if (bHasNormalTexture)
				{
					if (bIsSkinnedMesh)
						pMesh = new CSkinnedMeshIlluminatedTextured(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, pxmf3Normals, pxmf3TextureCoords0, nSubsets, pnSubSetIndices, ppnSubsetIndices, pxmu4SkinningBoneIndices, pxmf4SkinningBoneWeights);
					else
						pMesh = new CMeshIlluminatedTextured(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, pxmf3Normals, pxmf3TextureCoords0, nSubsets, pnSubSetIndices, ppnSubsetIndices);
				}
				else if (bHasNormal)
				{
					if (bIsSkinnedMesh)
						pMesh = new CSkinnedMeshIlluminated(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, pxmf3Normals, nSubsets, pnSubSetIndices, ppnSubsetIndices, pxmu4SkinningBoneIndices, pxmf4SkinningBoneWeights);
					else
						pMesh = new CMeshIlluminated(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, pxmf3Normals, nSubsets, pnSubSetIndices, ppnSubsetIndices);
				}
				else if (bHasTexture)
				{
					pMesh = new CMeshTextured(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, pxmf3TextureCoords0, nSubsets, pnSubSetIndices, ppnSubsetIndices);
				}
				else
				{
					pMesh = new CMesh(pd3dDevice, pd3dCommandList, nVertices, pxmf3Positions, nSubsets, pnSubSetIndices, ppnSubsetIndices);
				}

				if (bIsSkinnedMesh)
				{
					pMesh->SetSkinningBoneInfo(pstrSkinnedMeshName, nSkinningBones, ppstrSkinningBoneNames, pxmf4x4MeshToBoneOffsets);
					pMesh->CreateSkinningBoneTransformVariables(pd3dDevice, pd3dCommandList);
				}

				if (pRootShader)
				{
					UINT ncbElementBytes = ((sizeof(CB_GAMEOBJECT_INFO) + 255) & ~255);
					ID3D12Resource *pd3dcbResource = CreateShaderVariables(pd3dDevice, pd3dCommandList);

					D3D12_GPU_DESCRIPTOR_HANDLE d3dGpuDescriptorHandle = pRootShader->CreateConstantBufferViews(pd3dDevice, 1, pd3dcbResource, ncbElementBytes);
					SetCbvGPUDescriptorHandle(d3dGpuDescriptorHandle);
				}

			}

			if (pMesh) SetMesh(0, pMesh);

			if (pxmf3Positions) delete[] pxmf3Positions;
			if (pxmf3Normals) delete[] pxmf3Normals;
			if (pxmf3TextureCoords0) delete[] pxmf3TextureCoords0;
			if (pxmf3TextureCoords1) delete[] pxmf3TextureCoords1;
			if (pnIndices) delete[] pnIndices;

			if (pnSubsetStarts) delete[] pnSubsetStarts;
			if (nSubsets > 0)
			{
				if (ppnSubsetIndices)
				{
					for (int i = 0; i < nSubsets; i++) if (ppnSubsetIndices[i]) delete[] ppnSubsetIndices[i];
					delete[] ppnSubsetIndices;
				}
			}
			if (nMaterials > 0)
			{
				if (ppstrAlbedoTextureNames)
				{
					for (int i = 0; i < nMaterials; i++) if (ppstrAlbedoTextureNames[i]) delete[] ppstrAlbedoTextureNames[i];
					delete[] ppstrAlbedoTextureNames;
				}
				if (ppstrEmissionTextureNames)
				{
					for (int i = 0; i < nMaterials; i++) if (ppstrEmissionTextureNames[i]) delete[] ppstrEmissionTextureNames[i];
					delete[] ppstrEmissionTextureNames;
				}
				
				if (pxmf4MaterialAlbedos) delete[] pxmf4MaterialAlbedos;
				if (pnAlbedoTextures) delete[] pnAlbedoTextures;
			}

			if (pxmu4SkinningBoneIndices) delete[] pxmu4SkinningBoneIndices;
			if (pxmf4SkinningBoneWeights) delete[] pxmf4SkinningBoneWeights;

			break;
		}
	}
}

void CGameObject::LoadAnimationFromFile(wifstream& InFile)
{
	_TCHAR pstrToken[64] ={ '\0' };
	TCHAR pstrAnimationSetName[64] ={ '\0' };
	TCHAR pstrSkinnedMeshName[64] ={ '\0' };
	float fAnimationLength = 0.0f;
	int nAnimationSets = 0, nSkinnedMeshes = 0, nSkinnedMesh = 0, nAnimationSet = 0, nFramesPerSecond = 0, nKeyFrames = 0;
	CSkinnedAnimationSets **ppSkinnedAnimationSets = NULL;
	CMesh *pSkinnedMesh = NULL;

	for ( ; ; )
	{
		InFile >> pstrToken;
		if (!InFile) break;

		if (!_tcscmp(pstrToken, _T("AnimationSets:")))
		{
			InFile >> nAnimationSets;
			InFile >> nSkinnedMeshes;

			ppSkinnedAnimationSets = new CSkinnedAnimationSets*[nSkinnedMeshes];
			for (int i = 0; i < nSkinnedMeshes; i++) ppSkinnedAnimationSets[i] = new CSkinnedAnimationSets(nAnimationSets);
		}
		else if (!_tcscmp(pstrToken, _T("EndOfAnimationSets")))
		{
			if (ppSkinnedAnimationSets) delete[] ppSkinnedAnimationSets;
			break;
		}
		else if (!_tcscmp(pstrToken, _T("SkinnedMesh:")))
		{
			InFile >> nSkinnedMesh;
			InFile >> pstrSkinnedMeshName; 

			CGameObject *pGameObject = FindFrame(pstrSkinnedMeshName);
			pSkinnedMesh = pGameObject->GetSkinnedMesh();
			pSkinnedMesh->SetSkinnedAnimationSets(ppSkinnedAnimationSets[nSkinnedMesh]);
		}
		else if (!_tcscmp(pstrToken, _T("EndOfSkinnedMesh")))
		{
		}
		else if (!_tcscmp(pstrToken, _T("AnimationSet:")))
		{
			InFile >> nAnimationSet;
			InFile >> pstrAnimationSetName;
			InFile >> fAnimationLength;
			InFile >> nFramesPerSecond;
			InFile >> nKeyFrames;

			CSkinnedAnimationSet *pSkinnedAnimationSet = new CSkinnedAnimationSet(pstrAnimationSetName, fAnimationLength, nFramesPerSecond, nKeyFrames, this);
			ppSkinnedAnimationSets[nSkinnedMesh]->SetSkinnedAnimationSet(nAnimationSet, pSkinnedAnimationSet);

			pSkinnedAnimationSet->m_ppSkinningBoneFrameCaches = new CGameObject*[pSkinnedMesh->m_nSkinningBones];

			pSkinnedAnimationSet->m_pfKeyFrameTimes = new float[nKeyFrames];
			pSkinnedAnimationSet->m_ppxmf4x4KeyFrames = new XMFLOAT4X4*[nKeyFrames];
			for (int i = 0; i < nKeyFrames; i++) pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i] = new XMFLOAT4X4[pSkinnedMesh->m_nSkinningBones];

			for (int i = 0; i < pSkinnedMesh->m_nSkinningBones; i++)
			{
				pSkinnedAnimationSet->m_ppSkinningBoneFrameCaches[i] = FindFrame(pSkinnedMesh->m_ppstrSkinningBoneNames[i]);
#ifdef _WITH_DEBUG_FRAME_HIERARCHY
				TCHAR pstrDebug[128] ={ 0 };
				_stprintf_s(pstrDebug, 128, _T("BoneNames[%d]: %s %s %s\n"), i, pstrToken, pSkinnedAnimationSet->m_ppSkinningBoneFrameCaches[i]->m_pstrFrameName, pSkinnedMesh->m_ppstrSkinningBoneNames[i]);
				OutputDebugString(pstrDebug);
#endif
			}

			for (int i = 0; i < pSkinnedAnimationSet->m_nKeyFrames; i++)
			{
				InFile >> pstrToken;
				if (!_tcscmp(pstrToken, _T("Transforms:")))
				{
					InFile >> pstrToken; //i
					InFile >> pSkinnedAnimationSet->m_pfKeyFrameTimes[i];
					for (int j = 0; j < pSkinnedMesh->m_nSkinningBones; j++)
					{
						InFile >> pstrToken;
						if (!_tcscmp(pstrToken, _T("Transform:")))
						{
							InFile >> pstrToken; //j
							InFile >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._11 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._12 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._13 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._14;
							InFile >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._21 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._22 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._23 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._24;
							InFile >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._31 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._32 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._33 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._34;
							InFile >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._41 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._42 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._43 >> pSkinnedAnimationSet->m_ppxmf4x4KeyFrames[i][j]._44;
						}
					}
				}
			}
		}
		else if (!_tcscmp(pstrToken, _T("EndOfAnimationSet")))
		{
		}
	}
}

void CGameObject::PrintFrameInfo(CGameObject *pGameObject, CGameObject *pParent)
{
	TCHAR pstrDebug[128] = { 0 };

	_stprintf_s(pstrDebug, 128, _T("(Frame: %p) (Parent: %p)\n"), pGameObject, pParent);
	OutputDebugString(pstrDebug);

	if (pGameObject->m_pSibling) PrintFrameInfo(pGameObject->m_pSibling, pParent);
	if (pGameObject->m_pChild) PrintFrameInfo(pGameObject->m_pChild, pGameObject);
}

void CGameObject::LoadGeometryAndAnimationFromFile(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature, CShader *pRootShader, TCHAR *pstrFileName, bool bHasAnimation)
{
	wifstream InFile(pstrFileName);
	LoadFrameHierarchyFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pRootShader, this, bHasAnimation, InFile);

#ifdef _WITH_DEBUG_FRAME_HIERARCHY
	TCHAR pstrDebug[128] ={ 0 };
	_stprintf_s(pstrDebug, 128, _T("Loaded Frame Hierarchy\n"));
	OutputDebugString(pstrDebug);

	PrintFrameInfo(this, NULL);
#endif

	if (bHasAnimation) LoadAnimationFromFile(InFile);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CRotatingObject::CRotatingObject(int nMeshes)
{
	m_xmf3RotationAxis = XMFLOAT3(0.0f, 1.0f, 0.0f);
	m_fRotationSpeed = 15.0f;
}

CRotatingObject::~CRotatingObject()
{
}

void CRotatingObject::Animate(float fTimeElapsed)
{
	CGameObject::Rotate(&m_xmf3RotationAxis, m_fRotationSpeed * fTimeElapsed);
}

void CRotatingObject::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera)
{
	CGameObject::Render(pd3dCommandList, pCamera);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CRevolvingObject::CRevolvingObject(int nMeshes)
{
	m_xmf3RevolutionAxis = XMFLOAT3(1.0f, 0.0f, 0.0f);
	m_fRevolutionSpeed = 0.0f;
}

CRevolvingObject::~CRevolvingObject()
{
}

void CRevolvingObject::Animate(float fTimeElapsed)
{
	XMMATRIX mtxRotate = XMMatrixRotationAxis(XMLoadFloat3(&m_xmf3RevolutionAxis), XMConvertToRadians(m_fRevolutionSpeed * fTimeElapsed));
	m_xmf4x4World = Matrix4x4::Multiply(m_xmf4x4World, mtxRotate);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CApacheHellicopter::CApacheHellicopter(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedShader *pShader = new CIlluminatedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 33, 0); //Child: 32

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"../Assets/Model/Apache.txt", false);

	m_pRotorFrame = FindFrame(_T("rotor"));
}

CApacheHellicopter::~CApacheHellicopter()
{
}

void CApacheHellicopter::Animate(float fTimeElapsed)
{
	if (m_pRotorFrame)
	{
		XMMATRIX xmmtxRotate = XMMatrixRotationY(XMConvertToRadians(360.0f * 3.0f) * fTimeElapsed);
		m_pRotorFrame->m_xmf4x4ToParentTransform = Matrix4x4::Multiply(xmmtxRotate, m_pRotorFrame->m_xmf4x4ToParentTransform);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CGunshipHellicopter::CGunshipHellicopter(int nMeshes) : CGameObject(nMeshes)
{
	m_pRotorFrame = NULL;
	m_pBackRotorFrame = NULL;
	m_pHellfileMissileFrame = NULL;
}

CGunshipHellicopter::CGunshipHellicopter(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedTexturedShader *pShader = new CIlluminatedTexturedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 5, 2); //Child: 4, Texture: 2

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"../Assets/Model/Gunship.txt", false);

	m_pRotorFrame = FindFrame(_T("Rotor"));
	m_pBackRotorFrame = FindFrame(_T("Back_Rotor"));

	m_pHellfileMissileFrame = FindFrame(_T("Hellfire_Missile"));
	if (m_pHellfileMissileFrame) m_pHellfileMissileFrame->m_bActive = false;

	SetScale(2.0f, 2.0f, 2.0f);
	Rotate(0.0f, 180.0f, 0.0f);
}

CGunshipHellicopter::~CGunshipHellicopter()
{
}

void CGunshipHellicopter::Animate(float fTimeElapsed)
{
	if (m_pRotorFrame)
	{
		XMMATRIX xmmtxRotate = XMMatrixRotationY(XMConvertToRadians(360.0f * 3.0f) * fTimeElapsed);
		m_pRotorFrame->m_xmf4x4ToParentTransform = Matrix4x4::Multiply(xmmtxRotate, m_pRotorFrame->m_xmf4x4ToParentTransform);
	}

	if (m_pBackRotorFrame)
	{
		XMMATRIX xmmtxRotate = XMMatrixRotationX(XMConvertToRadians(360.0f * 3.0f) * fTimeElapsed);
		m_pBackRotorFrame->m_xmf4x4ToParentTransform = Matrix4x4::Multiply(xmmtxRotate, m_pBackRotorFrame->m_xmf4x4ToParentTransform);
	}
}

CGunshipHellicopter *CGunshipHellicopter::Clone(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature)
{
	CIlluminatedTexturedShader *pShader = new CIlluminatedTexturedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 5, 2); //Child: 4, Texture: 2

	CGunshipHellicopter *pCloneGunship = new CGunshipHellicopter(m_nMeshes);

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	pCloneGunship->SetMaterial(0, pMaterial);

	CGameObject::Clone(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, pCloneGunship, pCloneGunship, pCloneGunship);

#ifdef _WITH_DEBUG_FRAME_HIERARCHY
	TCHAR pstrDebug[128] = { 0 };
	_stprintf_s(pstrDebug, 128, _T("Cloned Frame Hierarchy\n"));
	OutputDebugString(pstrDebug);

	PrintFrameInfo(pCloneGunship, NULL);
#endif

	pCloneGunship->m_pRotorFrame = pCloneGunship->FindFrame(_T("Rotor"));
	pCloneGunship->m_pBackRotorFrame = pCloneGunship->FindFrame(_T("Back_Rotor"));

	pCloneGunship->m_pHellfileMissileFrame = pCloneGunship->FindFrame(_T("Hellfire_Missile"));
	if (pCloneGunship->m_pHellfileMissileFrame) pCloneGunship->m_pHellfileMissileFrame->m_bActive = false;

	return(pCloneGunship);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CFlyerShip::CFlyerShip(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedTexturedShader *pShader = new CIlluminatedTexturedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 1, 2); //Child: 0, Texture: 1

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"../Assets/Model/Flyer.txt", false);
}

CFlyerShip::~CFlyerShip()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CAbramsTank::CAbramsTank(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedShader *pShader = new CIlluminatedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 257, 0); //Child: 18+220+15+4, Texture: 0

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"../Assets/Model/M1 Abrams.txt", false);

	SetScale(0.2f, 0.2f, 0.2f);
}

CAbramsTank::~CAbramsTank()
{
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CAngrybot::CAngrybot(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedTexturedShader *pShader = new CIlluminatedTexturedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 48 + 1, 1); //Child: 48, Texture: 1

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"Model/AngrybotPlayer.txt", true);

	SetScale(10.0f, 10.0f, 10.0f);
}

CAngrybot::~CAngrybot()
{
}

void CAngrybot::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera)
{
	CGameObject::Render(pd3dCommandList, pCamera);
}

////////////////////////////////////////////////////////////////////////////////////////////////////
//
CMonster::CMonster(ID3D12Device *pd3dDevice, ID3D12GraphicsCommandList *pd3dCommandList, ID3D12RootSignature *pd3dGraphicsRootSignature) : CGameObject(0, 1)
{
	CIlluminatedTexturedShader *pShader = new CIlluminatedTexturedShader();
	pShader->CreateShader(pd3dDevice, pd3dGraphicsRootSignature);
	pShader->CreateShaderVariables(pd3dDevice, pd3dCommandList);
	pShader->CreateCbvSrvDescriptorHeaps(pd3dDevice, 78 + 1, 1); //Child: 78, Texture: 1

	CMaterial *pMaterial = new CMaterial();
	pMaterial->SetShader(pShader);
	SetMaterial(0, pMaterial);

	LoadGeometryAndAnimationFromFile(pd3dDevice, pd3dCommandList, pd3dGraphicsRootSignature, pShader, L"../Assets/Model/Monster.txt", true);

	SetScale(10.0f, 10.0f, 10.0f);
}

CMonster::~CMonster()
{
}

void CMonster::Render(ID3D12GraphicsCommandList *pd3dCommandList, CCamera *pCamera)
{
	CGameObject::Render(pd3dCommandList, pCamera);
}
